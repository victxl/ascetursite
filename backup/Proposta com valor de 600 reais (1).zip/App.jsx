import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { CheckCircle, Clock, Users, Target, Zap, Mail, Phone, MapPin, Heart, Globe, Lightbulb, TreePine, Palette, Trophy, Camera, ArrowRight } from 'lucide-react'
import AsceturLogo from './assets/logo_ascetur.png'
import './App.css'

function App() {
  const [activeSection, setActiveSection] = useState('home')

  const scrollToSection = (sectionId) => {
    setActiveSection(sectionId)
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-yellow-50 to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img src={AsceturLogo} alt="ASCETUR Logo" className="h-10" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-blue-500 bg-clip-text text-transparent">
                ASCETUR
              </h1>
            </div>
            <nav className="hidden md:flex space-x-6">
              {['home', 'sobre', 'atuacao', 'impacto', 'news', 'contato'].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className={`px-4 py-2 rounded-full transition-all duration-300 ${
                    activeSection === section
                      ? 'bg-gradient-to-r from-orange-500 to-blue-500 text-white shadow-lg'
                      : 'text-gray-600 hover:text-orange-600 hover:bg-orange-50'
                  }`}
                >
                  {section === 'home' ? 'Início' : 
                   section === 'sobre' ? 'Sobre Nós' :
                   section === 'atuacao' ? 'Atuação' :
                   section === 'impacto' ? 'Impacto' :
                   section === 'news' ? 'News' :
                   'Contato'}
                </button>
              ))}
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="py-20 px-6">
        <div className="container mx-auto text-center">
          <div className="mb-8">
            <Badge className="bg-gradient-to-r from-orange-400 to-yellow-500 text-white px-6 py-2 text-lg mb-6">
              Transformando Vidas
            </Badge>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="bg-gradient-to-r from-orange-600 via-yellow-600 to-blue-600 bg-clip-text text-transparent">
                Cultura, Esporte
              </span>
              <br />
              <span className="text-gray-800">e Turismo</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Transformando Vidas Através da Cultura, Esporte e Turismo, 
              Impulsionados pelo Empreendedorismo e Tecnologia.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              onClick={() => scrollToSection('atuacao')}
              className="bg-gradient-to-r from-orange-500 to-blue-500 hover:from-orange-600 hover:to-blue-600 text-white px-8 py-4 text-lg rounded-full shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              Conheça Nossa Atuação
            </Button>
            <Button 
              onClick={() => scrollToSection('contato')}
              variant="outline" 
              className="border-2 border-blue-300 text-blue-600 hover:bg-blue-50 px-8 py-4 text-lg rounded-full"
            >
              Apoie-nos
            </Button>
          </div>

          {/* Areas Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <Card className="bg-gradient-to-br from-orange-400 to-orange-600 text-white border-0 shadow-xl">
              <CardContent className="p-6 text-center">
                <Palette className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">Cultura</h3>
                <p className="text-orange-100">Arte e Educação</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-blue-400 to-blue-600 text-white border-0 shadow-xl">
              <CardContent className="p-6 text-center">
                <Trophy className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">Esporte</h3>
                <p className="text-blue-100">Bem-Estar</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-yellow-400 to-yellow-600 text-white border-0 shadow-xl">
              <CardContent className="p-6 text-center">
                <TreePine className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">Turismo</h3>
                <p className="text-yellow-100">Sustentável</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Sobre Nós Section */}
      <section id="sobre" className="py-20 px-6 bg-white/50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-gradient-to-r from-orange-400 to-blue-500 text-white px-6 py-2 text-lg mb-6">
              Sobre Nós
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-orange-600 to-blue-600 bg-clip-text text-transparent">
              Nossa História
            </h2>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
            <Card className="bg-gradient-to-br from-white to-orange-50 border-0 shadow-2xl">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-orange-600 mb-4">Nossa Missão</h3>
                <p className="text-lg text-gray-700 leading-relaxed mb-6">
                  Desde 2008, a ASCETUR atua como uma força transformadora, 
                  promovendo o desenvolvimento social através da cultura, esporte e turismo, 
                  sempre com base no empreendedorismo e tecnologia.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span>Legalidade e transparência</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span>Impessoalidade e eficiência</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span>Não-discriminação</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-white to-blue-50 border-0 shadow-2xl">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-blue-600 mb-4">Nosso Público</h3>
                <p className="text-lg text-gray-700 leading-relaxed mb-6">
                  Atuamos com atenção especial a grupos que mais necessitam de apoio, 
                  criando oportunidades e fortalecendo laços sociais.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Heart className="w-5 h-5 text-pink-500" />
                    <span>Crianças e jovens em vulnerabilidade</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Heart className="w-5 h-5 text-pink-500" />
                    <span>População LGBTQIAPN+</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Heart className="w-5 h-5 text-pink-500" />
                    <span>Fortalecimento de mulheres</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Card className="max-w-4xl mx-auto bg-gradient-to-r from-orange-100 to-blue-100 border-0 shadow-xl">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Nosso Alcance</h3>
                <p className="text-lg text-gray-700">
                  Nossa atuação compreende todo o Distrito Federal, a RIDE, o território nacional - 
                  especialmente em áreas dentro dos biomas da Amazônia e do Cerrado.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Atuação Section */}
      <section id="atuacao" className="py-20 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-gradient-to-r from-blue-400 to-orange-500 text-white px-6 py-2 text-lg mb-6">
              Nossa Atuação
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-orange-600 bg-clip-text text-transparent">
              Como Geramos Impacto
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Transformamos vidas e comunidades por meio de iniciativas focadas em Cultura, 
              Esporte e Turismo, com a inovadora base do Empreendedorismo e Tecnologia.
            </p>
          </div>

          {/* Serviços */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-16">
            <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <CardHeader>
                <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full flex items-center justify-center mb-4">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-orange-800">Programas e Projetos</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-4">
                  Desenvolvemos e executamos iniciativas de longo prazo, com objetivos claros 
                  de desenvolvimento social, cultural, esportivo e turístico.
                </p>
                <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                  Ver Projetos <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <CardHeader>
                <div className="w-16 h-16 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center mb-4">
                  <Lightbulb className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-blue-800">Consultoria</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-4">
                  Oferecemos assessoria estratégica e consultoria especializada para organizações, 
                  governos e empresas que desejam desenvolver projetos sociais.
                </p>
                <Button className="bg-blue-500 hover:bg-blue-600 text-white">
                  Saiba Mais <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-200 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <CardHeader>
                <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mb-4">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-yellow-800">Pesquisa e Extensão</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-4">
                  Conduzimos estudos e pesquisas para identificar necessidades, avaliar a eficácia 
                  de nossas ações e desenvolver metodologias inovadoras.
                </p>
                <Button className="bg-yellow-500 hover:bg-yellow-600 text-white">
                  Publicações <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Áreas de Atuação */}
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-8">Nossos Projetos por Área</h3>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <Card className="bg-gradient-to-br from-orange-400 to-orange-600 text-white border-0 shadow-2xl">
              <CardContent className="p-8">
                <Palette className="w-16 h-16 mb-6" />
                <h3 className="text-3xl font-bold mb-4">Cultura, Arte e Educação</h3>
                <p className="text-orange-100 mb-6">
                  Exploramos a cultura como motor de transformação e inclusão. 
                  Conheça nossos projetos que resgatam tradições, valorizam talentos 
                  e promovem a educação artística.
                </p>
                <Button className="bg-white text-orange-600 hover:bg-gray-100">
                  Explorar Projetos Culturais
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-400 to-blue-600 text-white border-0 shadow-2xl">
              <CardContent className="p-8">
                <Trophy className="w-16 h-16 mb-6" />
                <h3 className="text-3xl font-bold mb-4">Esporte e Bem-Estar</h3>
                <p className="text-blue-100 mb-6">
                  Acreditamos no poder do esporte para promover saúde, disciplina 
                  e trabalho em equipe. Veja como nossos projetos incentivam a prática 
                  esportiva e a formação de cidadãos.
                </p>
                <Button className="bg-white text-blue-600 hover:bg-gray-100">
                  Ver Projetos Esportivos
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-400 to-yellow-600 text-white border-0 shadow-2xl">
              <CardContent className="p-8">
                <TreePine className="w-16 h-16 mb-6" />
                <h3 className="text-3xl font-bold mb-4">Turismo Sustentável</h3>
                <p className="text-yellow-100 mb-6">
                  Promovemos um turismo consciente e responsável que valoriza as 
                  comunidades e preserva o meio ambiente. Conheça nossas rotas e 
                  iniciativas que unem lazer e sustentabilidade.
                </p>
                <Button className="bg-white text-yellow-600 hover:bg-gray-100">
                  Descobrir Roteiros
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-400 to-purple-600 text-white border-0 shadow-2xl">
              <CardContent className="p-8">
                <Zap className="w-16 h-16 mb-6" />
                <h3 className="text-3xl font-bold mb-4">Empreendedorismo e Inovação</h3>
                <p className="text-purple-100 mb-6">
                  Explicamos como o empreendedorismo impulsiona as iniciativas da ASCETUR. 
                  Detalhamos workshops, mentorias e apoio a empreendedores nos setores 
                  cultural, esportivo e turístico.
                </p>
                <Button className="bg-white text-purple-600 hover:bg-gray-100">
                  Programas de Capacitação
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-16">
            <Card className="max-w-4xl mx-auto bg-gradient-to-r from-orange-100 to-blue-100 border-0 shadow-xl">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Construa um Futuro Conosco</h3>
                <p className="text-lg text-gray-700 mb-6">
                  Seja nosso parceiro em consultoria, apoie um de nossos projetos ou saiba 
                  como a pesquisa pode ajudar a sua organização. Entre em contato e vamos 
                  juntos gerar mais impacto social.
                </p>
                <Button 
                  onClick={() => scrollToSection('contato')}
                  className="bg-gradient-to-r from-orange-500 to-blue-500 hover:from-orange-600 hover:to-blue-600 text-white px-8 py-3"
                >
                  Fale Conosco
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Impacto Section */}
      <section id="impacto" className="py-20 px-6 bg-gradient-to-r from-orange-50 to-blue-50">
        <div className="container mx-auto text-center">
          <Badge className="bg-gradient-to-r from-orange-400 to-blue-500 text-white px-6 py-2 text-lg mb-6">
            Nosso Impacto
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-12 bg-gradient-to-r from-orange-600 to-blue-600 bg-clip-text text-transparent">
            Reconhecimento e Resultados
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-12">
            <Card className="bg-white border-0 shadow-xl p-6">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Selo Social</h3>
              <p className="text-gray-600">Reconhecimento oficial do impacto social</p>
            </Card>
            
            <Card className="bg-white border-0 shadow-xl p-6">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Palette className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Prêmio Artista FAC</h3>
              <p className="text-gray-600">Ana Sofia (Presidente)</p>
            </Card>
            
            <Card className="bg-white border-0 shadow-xl p-6">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Prêmio BRICS</h3>
              <p className="text-gray-600">Paula Pantoja</p>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <Card className="bg-white border-0 shadow-xl">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-orange-600 mb-4">Alinhamento Global</h3>
                <p className="text-lg text-gray-700 mb-4">
                  Nosso trabalho está alinhado com os 17 Objetivos de Desenvolvimento 
                  Sustentável (ODS) da ONU, demonstrando nosso compromisso global.
                </p>
                <div className="flex items-center space-x-2">
                  <Badge className="bg-orange-100 text-orange-800">ODS</Badge>
                  <Badge className="bg-blue-100 text-blue-800">ESG</Badge>
                  <Badge className="bg-green-100 text-green-800">COP 30</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-xl">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-blue-600 mb-4">Dados de Impacto</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Pessoas Assistidas</span>
                    <span className="text-2xl font-bold text-blue-600">1000+</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Comunidades Beneficiadas</span>
                    <span className="text-2xl font-bold text-orange-600">50+</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Projetos Realizados</span>
                    <span className="text-2xl font-bold text-yellow-600">25+</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* News Section */}
      <section id="news" className="py-20 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-gradient-to-r from-blue-400 to-orange-500 text-white px-6 py-2 text-lg mb-6">
              Últimas Notícias
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-orange-600 bg-clip-text text-transparent">
              News & Atualizações
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="bg-white border-0 shadow-xl overflow-hidden">
              <div className="h-48 bg-gradient-to-r from-orange-400 to-orange-600 flex items-center justify-center">
                <Camera className="w-16 h-16 text-white" />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2">Novo Projeto Cultural</h3>
                <p className="text-gray-600 mb-4">
                  Lançamento do projeto de arte e educação para jovens em vulnerabilidade social.
                </p>
                <Button variant="outline" className="w-full">
                  Leia Mais
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-xl overflow-hidden">
              <div className="h-48 bg-gradient-to-r from-blue-400 to-blue-600 flex items-center justify-center">
                <Trophy className="w-16 h-16 text-white" />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2">Campeonato Esportivo</h3>
                <p className="text-gray-600 mb-4">
                  Organização do primeiro campeonato comunitário de futebol feminino.
                </p>
                <Button variant="outline" className="w-full">
                  Leia Mais
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-white border-0 shadow-xl overflow-hidden">
              <div className="h-48 bg-gradient-to-r from-yellow-400 to-yellow-600 flex items-center justify-center">
                <TreePine className="w-16 h-16 text-white" />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2">Rota Ecológica</h3>
                <p className="text-gray-600 mb-4">
                  Nova rota de turismo sustentável no Cerrado em parceria com comunidades locais.
                </p>
                <Button variant="outline" className="w-full">
                  Leia Mais
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Button className="bg-gradient-to-r from-orange-500 to-blue-500 hover:from-orange-600 hover:to-blue-600 text-white px-8 py-3">
              Ver Todas as Notícias
            </Button>
          </div>
        </div>
      </section>

      {/* Contato Section */}
      <section id="contato" className="py-20 px-6 bg-gradient-to-r from-blue-50 to-orange-50">
        <div className="container mx-auto text-center">
          <Badge className="bg-gradient-to-r from-blue-400 to-orange-500 text-white px-6 py-2 text-lg mb-6">
            Contato
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-12 bg-gradient-to-r from-blue-600 to-orange-600 bg-clip-text text-transparent">
            Fale Conosco
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto mb-12">
            <Card className="bg-white border-0 shadow-xl p-6">
              <Mail className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Email</h3>
              <p className="text-gray-600">contato@ascetur.com.br</p>
            </Card>
            <Card className="bg-white border-0 shadow-xl p-6">
              <Phone className="w-12 h-12 text-orange-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Telefone</h3>
              <p className="text-gray-600">(61) 99853-8516</p>
            </Card>
            <Card className="bg-white border-0 shadow-xl p-6">
              <MapPin className="w-12 h-12 text-yellow-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Endereço</h3>
              <p className="text-gray-600">SEPN 707/907 Bloco 2, Sala 2311 - Ceub Asa Norte</p>
            </Card>
          </div>

          <Card className="max-w-2xl mx-auto bg-white border-0 shadow-xl">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-6">Formulário de Contato</h3>
              <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="Seu Nome" 
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
                <input 
                  type="email" 
                  placeholder="Seu Email" 
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
                <textarea 
                  placeholder="Sua Mensagem" 
                  rows="4"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                ></textarea>
                <Button className="w-full bg-gradient-to-r from-orange-500 to-blue-500 hover:from-orange-600 hover:to-blue-600 text-white py-3">
                  Enviar Mensagem
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-gray-800 to-gray-900 text-white py-12 px-6">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <img src={AsceturLogo} alt="ASCETUR Logo" className="h-12" />
            <h3 className="text-2xl font-bold">ASCETUR</h3>
          </div>
          <p className="text-gray-300 mb-6">
            Associação Cultural, Esportiva & Turística
          </p>
          <p className="text-gray-400 mb-6">
            Transformando vidas através da cultura, esporte e turismo
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-gradient-to-r from-orange-500 to-blue-500 hover:from-orange-600 hover:to-blue-600"
              onClick={() => window.open('mailto:contato@ascetur.com.br', '_blank')}
            >
              Entrar em Contato
            </Button>
            <Button 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-gray-800"
              onClick={() => scrollToSection('home')}
            >
              Voltar ao Topo
            </Button>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700">
            <p className="text-gray-400 text-sm">
              © 2024 ASCETUR. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

